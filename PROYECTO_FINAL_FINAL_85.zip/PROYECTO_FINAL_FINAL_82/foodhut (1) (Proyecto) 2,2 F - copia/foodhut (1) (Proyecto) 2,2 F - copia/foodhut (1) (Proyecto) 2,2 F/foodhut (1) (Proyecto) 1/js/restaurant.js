// PRODUCTOS
const productos = [
    // Computadores
    {
        id: "Entrada-01",
        titulo: "Ensalda César 01",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6EaM62vAFSmaeopJlkKyvUqICvqopQiX_dQ&s",
        categoria: {
            nombre: "Ensalda César 01",
            id: "Ensalda César 01"
        },
        precio: 1700000
    },
    {
        id: "Caldo de pollo-02",
        titulo: "Caldo de pollo",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmx84E1eH1Yk9TxhDewtyI8RHEuarmSyxkFw&s",
        categoria: {
            nombre: "Caldo de pollo",
            id: "Caldo de pollo"
        },
        precio: 4745000
    },
    {
        id: "Filete de res",
        titulo: "Filete de Res ",
        imagen: "https://buenprovecho.hn/wp-content/uploads/2020/01/Filete-de-res-a-la-pimienta.jpg",
        categoria: {
            nombre: "Filete de res",
            id: "Filete de res"
        },
        precio: 1053000
    },
    // Celulares
    {
        id: "Hamburugesa Clásica",
        titulo: "Hamburugesa Clásica",
        imagen: "https://www.recetasnestle.com.co/sites/default/files/srh_recipes/3e90278b3f143803e0c8fbe32a04bdd6.jpg",
        categoria: {
            nombre: "Hamburugesa Clásica",
            id: "Hamburugesa Clásica"
        },
        precio: 45000
    },
    {
        id: "Tiramisu",
        titulo: "Tiramisu",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0F9nIaEyFnjF3KTZYCkiAhBJtaDPliC3YqA&s",
        categoria: {
            nombre: "Tiramisu",
            id: "Tiramisu"
        },
        precio: 40000
    },
    {
        id: "Cheesecake",
        titulo: "Cheesecake",
        imagen: "https://www.recetasnestlecam.com/sites/default/files/srh_recipes/07892f02f7c57b83d5703b4ee924221e.jpg",
        categoria: {
            nombre: "Cheesecake",
            id: "Cheesecake"
        },
        precio: 35000
    },
];

const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");
function cargarProductos(productosElegidos) {
    // Limpia el contenedor de productos.
    contenedorProductos.innerHTML="";

    if (productosElegidos.length === 0) {
        contenedorProductos.innerHTML = "<p>No hay productos disponibles</p>";
        return;
    }

    // Crea los elementos de los productos.
    productosElegidos.forEach(producto => {
        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <button class="producto-agregar" id="${producto.id}">Agregar</button>
            </div>
        `;
        contenedorProductos.append(div);
    });

    // Actualiza los botones para habilitar eventos de clic.
    actualizarBotonesAgregar();
}


cargarProductos(productos);

botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");

        if (e.currentTarget.id !== "todos") {
            const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
            tituloPrincipal.innerText = productosBoton[0]?.categoria.nombre || "Categoría no encontrada";
            cargarProductos(productosBoton);
        } else {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
        }
    });
});

function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");
    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

let productosEnCarrito = JSON.parse(localStorage.getItem("productos-en-carrito")) || [];
actualizarNumerito();

function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if (productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    const nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito};