// Programación de transición entre formularios
const signUpButton = document.getElementById("signUp"); // Botón de registro
const signInButton = document.getElementById("signIn"); // Botón de inicio de sesión
const container = document.getElementById("container");
const forgotPasswordLink = document.getElementById("forgotPassword"); // Enlace de recuperación de contraseña
const passwordField = document.getElementById("seña"); // Campo de contraseña
const passwordToggleIcon = document.getElementById("passwordToggleIcon"); // Icono de visibilidad de la contraseña

// Evento para mostrar el formulario de registro
if (signUpButton) {
    signUpButton.addEventListener("click", () => {
        container.classList.add("right-panel-active");
    });
}

// Evento para mostrar el formulario de inicio de sesión
if (signInButton) {
    signInButton.addEventListener("click", () => {
        container.classList.remove("right-panel-active");
    });
}

// Función para mostrar/ocultar la contraseña
function mostrarSeña() {
    if (passwordField.type === "password") {
        passwordField.type = "text";  // Cambiar a texto para mostrar la contraseña
        passwordToggleIcon.src = "icono_ojo_abierto.png";  // Cambiar el icono a "ojo abierto"
    } else {
        passwordField.type = "password";  // Volver a poner el tipo a contraseña para ocultarla
        passwordToggleIcon.src = "icono_ojo_cerrado.png";  // Cambiar el icono a "ojo cerrado"
    }
}

// Evento para manejar la recuperación de contraseña
if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", (event) => {
        event.preventDefault(); // Evita que se recargue la página
        const email = prompt("Por favor, ingresa tu correo para recibir instrucciones de recuperación de contraseña.");
        
        if (email) {
            alert("Hemos enviado un correo con las instrucciones para recuperar tu contraseña.");
            // Aquí podrías redirigir a una página o enviar el correo por medio de una API, por ejemplo:
            // window.location.href = "recuperar-contraseña.html";
        } else {
            alert("Por favor ingresa un correo válido.");
        }
    });
}

// Verificar si el campo de contraseña y el ícono existen antes de agregar el evento
if (passwordField && passwordToggleIcon) {
    passwordToggleIcon.addEventListener("click", mostrarSeña);
}
